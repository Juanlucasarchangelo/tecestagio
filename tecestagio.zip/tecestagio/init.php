<?php

//timezone

date_default_timezone_set('America/Sao_Paulo');

// conexão com o banco de dados
//define define uma constante
//nome ou ip servidor de banco de dados
define('BD_SERVIDOR','localhost');
//usuario para acesso ao BD
define('BD_USUARIO','archwebc_tecestagio');
//senha de acesso ao BD
define('BD_SENHA','Archweb.123#$@');
//nome do banco de dados
define('BD_BANCO','archwebc_tecestagio');

?>