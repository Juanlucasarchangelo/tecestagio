<?php

header("location: view/index.php");

?>